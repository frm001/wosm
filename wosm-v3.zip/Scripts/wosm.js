﻿/* Script de funcione generales
Autor: Fernando Rodelo Mármol
*/
if ($("#lmuser").html() == "") {
    $("#lmmat").hide();
    $("#lmmail").hide();
    $("#ltest").hide();
    $("#lmfin").hide();
} else {
    $("#lmmat").show();
    $("#lmmail").show();
    $("#ltest").show();
    $("#lmfin").show();
}

function addAdmin() {
    $.ajax({
        method: 'POST',
        url: '../api/sistema',
        dataType: 'json',
        async: false,
        data: {
            d0: "1", d1: $("#txtIdentifica").val(), d2: $("#txtNombre").val(), d3: $("#txtEmail").val(), d4: $("#txtTelefono").val()
        },
        success: function (data, textStatus, jqXHR) {
            if (data == 1) {
                $("#mensaje").html("El usuario administrador ha sido creado, por favor revise el buzón de correo para conocer la clave asignada.");
            } else {
                $("#mensaje").html("Esta opción solo esta permitida una vez en el sistema, si no puede ingregar al servicio genere una nueva clave  en ventala login, o contacte con su equipo de soporte.");               
            }
            $("#mAvisos").show();
        }
    });
}

// Funciones para Dispositivos
function addDevice() {
    $.ajax({
        method: 'POST',
        url: '../api/equipo',
        dataType: 'json',
        async: false,
        data: {
            id: $("#txtId").val(), nombre: $("#txtNombred").val(), serie: $("#txtSerie").val(),
            tipo: $("#cmbTipo").val(), auxa: $("#txtAxa").val(), auxb: $("#txtAuxb").val()
        },
        success: function (data, textStatus, jqXHR) {
            leeDevice(0);
        }
    });
}

function activaDevice(id, es) {
    $.ajax({
        method: 'POST',
        url: '../api/equipo',
        data:{id: id, serie: "0", tipo: "0", estado: es},
        success: function (data, textStatus, jqXHR) {
            leeDevice(0);
            if (textStatus == 200)
                alert("Proceso exitoso");
        }

    });
}

// Funciones para Cliente
function addCliente() {
    //var reg = JSON.stringify({ identifica: $("#txtIdentifica").val(), nombre: $("#txtNombrec").val(), email: $("#txtEmail").val(), telefono: $("#txtTelefono").val(), estado: 1 });    
    $.ajax({
        method: 'POST',
        url: '../api/cliente',
        dataType: 'json',
        async: false,
        data: { identifica: $("#txtIdentifica").val(), nombre: $("#txtNombrec").val(), email: $("#txtEmail").val(), telefono: $("#txtTelefono").val(), estado: 1 },
        success: function (data, textStatus, jqXHR) {
            leeCliente(0);
        }
    });
}

function activaCliente(i, p) {
    $.ajax({
        method: 'POST',
        url: '../api/cliente',
        dataType: 'json',
        data: {d0:"3", d1: i, d2: p},
        success: function (data, textStatus, jqXHR) {
            userDevice($("#txtId").val());
        }
    });
}


//@functions{
//        public string TokenHeaderValue()
//    {
//        string cookieToken, formToken;
//        AntiForgery.GetTokens(null, out cookieToken, out formToken);
//        return cookieToken + ":" + formToken;
//    }
//}

//$.ajax("api/values", {
//    type: "post",
//    contentType: "application/json",
//    data: {}, // JSON data goes here
//    dataType: "json",
//    headers: {
//        'RequestVerificationToken': '@TokenHeaderValue()'
//    }
//});

function inicioSession() {
    $.ajax({
        method: 'POST',
        url: '../Home/Validar',
        dataType: 'json',
        async: true,
        data: { d0: $("#txtUsername").val(), d1: $("#txtPassword").val(), d2:"0" },
        success: function (data, textStatus, jqXHR) {
            if (data==0) {
                $("#login-alert").html("Usuario y/o contraseña incorrectos.");
                $("#login-alert").show();
            } else {
                location.reload();
            }
        }
    });
}

function lostPwd() {
    var ema = $("#txtEmail").val();
    if (ema.length > 5) {
        $.ajax({
            method: 'POST',
            url: '../Home/Validar',
            dataType: 'json',
            async: true,
            data: { d0: ema, d1: "", d2: "1" },
            success: function (data, textStatus, jqXHR) {
                if (data == 0) {
                    $("#signupalert").html("Se presentaron errores en el proceso.");
                } else {
                    $("#signupalert").removeClass("alert-danger");
                    $("#signupalert").addClass("alert-success");
                    $("#signupalert").html("Su nueva clave se ha enviado al correo indicado.");                    
                }
                $("#signupalert").show();
            }
        });
    } else {
        $("#signupalert").removeClass("alert-success");
        $("#signupalert").addClass("alert-danger");
        $("#signupalert").html("Debe indicar un correo electrónico válido.");
        $("#signupalert").show();
    }
}

function loadModelo() {
    var i = $("#cmbTipo").val();
    var fila = "";
    if (i == "lx") {
        fila = "<option value='lx20s'>LX20S</option><option value='lx2nb'>LX2NB</option><option value='lx20b'>LX20B</option><option value='epx400'>EPX400</option>";
    } else if (i == "ex") {
        fila = "<option value = 'ex20'>EX20</option >";
    } else if (i == "cp") {
        fila = "<option value='cpx'>CPX</option>";
    }
    $("#cmbModelo").children().remove();
    $("#cmbModelo").append(fila);
}

// Licenciamiento
function updLicencia() {
    $.ajax({
        method: 'POST',
        url: '../Home/Validar',
        dataType: 'json',
        async: true,
        data: { d0: $("#txtIdentifica").val(), d1: "0", d2: "2" },
        success: function (data, textStatus, jqXHR) {
            if (data == 1) {
                $("#mensaje").html("El proceso se ha realizado exitosamente.");
                $("#mAvisos").show();
            } else {
                $("#mensaje").html("Se presentaron errores en el proceso, reintete nuevamente; si persiste el problema contacta a soporte técnico.");
                $("#mAvisos").removeClass("alert-success");
                $("#mAvisos").addClass("alert-danger");
                $("#mAvisos").show();
            }
        }
    });
}

// Procesos matricula
function addEquipocliente() {
    var datos = {
        idequipo: $("#txtId").val(), serieqp: $("#txtSerie").val(), nombreqp: $("#txtNombred").val(), tipoeqp: $("#cmbTipo").val(), modeleqp: $("#cmbModelo").val(), 
        imgtipo: $("#cmbImgtipo").val(), auxaeqp: $("#txtAuxa").val(), auxbeqp: $("#txtAuxb").val(), estadoeqp: 1, idcliente: $("#txtIdentifica").val(),
        nombrecli: $("#txtNombrec").val(), emailcli: $("#txtEmail").val(), telefonocli: $("#txtTelefono").val(), estadocli: 1, tipocli: $("#cmbTipocli").val()
    };
    $("#rotor").show();
    $.ajax({
        method: 'POST',
        url: '../api/eqcli',
        dataType: 'json',
        async: false,
        data: datos,
        success: function (data, textStatus, jqXHR) {
            $("#rotor").hide();
            $("#mensaje").html("El proceso se ha realizado exitosamente.");
            $("#mAvisos").show();
            leeDevice(0);
        }
    });
}

function cargaOsm() {
    $.ajax({
        method: 'POST',
        url: '../api/equipo',
        dataType: 'json',
        async: false,
        data: { id: 0, nombre: 0, serie: 0, tipo: 0 },
        success: function (data, textStatus, jqXHR) {
            leeDevice(0);
        }
    });
}

function updFndevices() {
    $.ajax({
        method: 'POST',
        url: '../api/equipo',
        dataType: 'json',
        async: false,
        data: { id: 1, nombre: 1, serie: 1, tipo: 1 },
        success: function (data, textStatus, jqXHR) {
            $("#mensaje").html("El proceso se ha realizado exitosamente.");
            $("#mAvisos").show();
        }
    });
}

function updBasedatos() {
    $.ajax({
        method: 'POST',
        url: '../api/equipo',
        dataType: 'json',
        async: false,
        data: { id: 2, nombre: 2, serie: 2, tipo: 2 },
        success: function (data, textStatus, jqXHR) {
        }
    });
}

function leeSerie() {
    $.ajax({
        method: 'GET',
        url: '../api/equipo',
        dataType: 'json',
        data: { id: 0, serie: $("#txtSerie").val(), tipo: $("#cmbTipo").val() },
        success: function (data, textStatus, jqXHR) {
            $.each(data, function (key, item) {
                $("#txtNombred").val(item.nombre);
                $("#cmbTipo").val(item.tipo);
                $("#cmbTipo").click();
                $("#cmbModelo").val(item.modelo);
                $("#cmbImgtipo").val(item.imgtipo);
                $("#txtAuxa").val(item.auxa);
                $("#txtAuxb").val(item.auxb);
            });
        }
    });
}

function leeCliente(p) {
    var uri = '../api/cliente/0';
    var fila = "";
    if (p == 0) {
        // Send an AJAX request
        $.getJSON(uri)
            .done(function (data) {
                // On success, 'data' contains a list of products.
                $("#tbClientes tbody tr").remove();
                $.each(data, function (key, item) {
                    if (item.estado == 0) {
                        fila = "<tr><td>" + item.nombre + "</td><td>" + item.email + "</td><td>" + item.telefono +
                            "</td><td><span onclick='activaCliente(" + item.identifica + ", 1)' class='glyphicon glyphicon-thumbs-down' title='Inactivo'></span>" +
                            "</td></tr>";
                    } else {
                        fila = "<tr><td>" + item.nombre + "</td><td>" + item.email + "</td><td>" + item.telefono +
                            "</td><td><span onclick='activaCliente(" + item.identifica + ", 0)' class='glyphicon glyphicon-thumbs-up' title='Activo'></span>" +
                            "</td></tr>";
                    }
                    $("#tbClientes tbody").append(fila);
                });
            });
    } else {
        uri = '../api/cliente/' + p;
        $.getJSON(uri)
            .done(function (data) {
                $.each(data, function (key, item) {
                    $("#txtIdentifica").val(item.identifica);
                    $("#txtNombrec").val(item.nombre);
                    $("#txtEmail").val(item.email);
                    $("#txtTelefono").val(item.telefono);
                });
            });
    }
}

function leeDevice(p) {
    var uri = '../api/equipo/0';
    var fila = "";
    if (p == 0) {
        // Send an AJAX request
        $.getJSON(uri)
            .done(function (data) {
                // On success, 'data' contains a list of products.
                $("#tbDevices tbody tr").remove();
                $.each(data, function (key, item) {
                    if (item.estado == 0) {
                        fila = "<tr class='resalta-gris'><td>" + item.nombre + "</td><td>" + item.serie + "</td><td>" + item.tipo + "</td><td>" + item.modelo +
                            "</td><td class='text-center'><a href='#' onclick='activaDevice(" + item.id + ", 1)' class='glyphicon glyphicon-thumbs-down' title='Activar'></a> ";
                    } else {
                        fila = "<tr class='resalta-amarillo'><td>" + item.nombre + "</td><td>" + item.serie + "</td><td>" + item.tipo + "</td><td>" + item.modelo +
                            "</td><td class='text-center'><a href='#' onclick='activaDevice(" + item.id + ", 0)' class='glyphicon glyphicon-thumbs-up' title='Desactivar'></a> ";
                    }
                    fila = fila + "<a href='#' onclick='leeDevice(" + item.id + ")' class='glyphicon glyphicon-edit' title='Editar'></a> " +
                        "<a href='#' onclick='userDevice(" + item.id + ")' class='glyphicon glyphicon-user' title='Usuarios' data-toggle='modal' data-target='#dlgUsers'></a> " +
                        "<a href='#' onclick='readFunxdevice(" + item.id + ")' class='glyphicon glyphicon-cog' title='Personalizar' data-toggle='modal' data-target='#dlgCustom'></a></td ></tr > ";

                    $("#tbDevices tbody").append(fila);
                });
            });
    } else {
        uri = '../api/equipo/' + p;
        $.getJSON(uri)
            .done(function (data) {
                $.each(data, function (key, item) {
                    $("#txtSerie").val(item.serie);
                    $("#txtNombred").val(item.nombre);
                    $("#cmbTipo").val(item.tipo);
                    $("#cmbTipo").click();
                    $("#cmbModelo").val(item.modelo);
                    $("#cmbImgtipo").val(item.imgtipo);
                    $("#txtAuxa").val(item.auxa);
                    $("#txtAuxb").val(item.auxb);
                });
            });
    }
}

function filterEstadoserie(p) {
    var uri = "";
    var fila = "";
    if (p == 1) {
        uri = '../api/equipo?pic=a&pid=0-' + $("#cmbFiltro").val();
    } else {
        uri = '../api/equipo?pic=a&pid=' + $("#txtBuscar").val() + "-2";
    }
    $.getJSON(uri)
        .done(function (data) {
            // On success, 'data' contains a list of products.
            $("#tbDevices tbody tr").remove();
            $.each(data, function (key, item) {
                if (item.estado == 0) {
                    fila = "<tr class='resalta-gris'><td>" + item.nombre + "</td><td>" + item.serie + "</td><td>" + item.tipo + "</td><td>" + item.modelo +
                        "</td><td class='text-center'><a href='#' onclick='activaDevice(" + item.id + ", 1)' class='glyphicon glyphicon-thumbs-down' title='Activar'></a> ";
                } else {
                    fila = "<tr class='resalta-amarillo'><td>" + item.nombre + "</td><td>" + item.serie + "</td><td>" + item.tipo + "</td><td>" + item.modelo +
                        "</td><td class='text-center'><a href='#' onclick='activaDevice(" + item.id + ", 0)' class='glyphicon glyphicon-thumbs-up' title='Desactivar'></a> ";
                }
                fila = fila + "<a href='#' onclick='leeDevice(" + item.id + ")' class='glyphicon glyphicon-edit' title='Editar'></a> " +
                    "<a href='#' onclick='userDevice(" + item.id + ")' class='glyphicon glyphicon-user' title='Usuarios' data-toggle='modal' data-target='#dlgUsers'></a> " +
                    "<a href='#' onclick='readFunxdevice(" + item.id + ")' class='glyphicon glyphicon-cog' title='Personalizar' data-toggle='modal' data-target='#dlgCustom'></a></td ></tr > ";

                $("#tbDevices tbody").append(fila);
            });
        });
}

function userDevice(p) {
    var uri = '../api/cliente/' + p + "-0";
    var fila = "";
    var titu = "";
    $.getJSON(uri)
        .done(function (data) {
            $("#tbUser tbody tr").remove();
            $.each(data, function (key, item) {
                if (item.estado == 0) {
                    fila = "<tr><td>" + item.nombre + "</td><td>" + item.email + "</td><td>" + item.telefono +
                        "</td><td><span onclick='activaCliente(" + item.identifica + ", 1)' class='glyphicon glyphicon-thumbs-down' title='Activar'></span>" +
                        "</td></tr>";
                } else {
                    fila = "<tr><td>" + item.nombre + "</td><td>" + item.email + "</td><td>" + item.telefono +
                        "</td><td><span onclick='activaCliente(" + item.identifica + ", 0)' class='glyphicon glyphicon-thumbs-up' title='Desactivar'></span>" +
                        "</td></tr>";
                }
                titu = item.nombre;
                $("#tbUser tbody").append(fila);
            });
            $("#spnDlgtit1").html("Usuarios de " + titu);
        });
    $("#txtId").val(p);
}

function readFunxdevice(p) {
    var uri = '../api/equipo?pid=' + p + '&pidf=0&pidp=0';
    var fila = "";
    var titu = "";
    $.getJSON(uri)
        .done(function (data) {
            $("#cmbFuncion").children().remove();
            $.each(data, function (key, item) {
                fila = "<option value='" + item.idfuncion + "'>" + item.nomfuncion + "</option>";
                titu = item.nomdevice;
                $("#cmbFuncion").append(fila);
                $("#txtId").val(item.iddevice);
            });
            $("#spnDlgtit2").html(titu);
        });

    readFuncustom(p);
}

function readFuncustom(p) {
    var fila = "";
    var uri = '../api/eqcli/' + p;
    $.getJSON(uri)
        .done(function (data) {
            $("#tbCustom tbody tr").remove();
            $.each(data, function (key, item) {
                fila = "<tr><td>" + item.d1 + "</td><td>" + item.d3 + "</td></tr>";
                $("#tbCustom tbody").append(fila);
            });
        });
}

function addCustomfn() {
    $.ajax({
        method: 'POST',
        url: '../api/funcion',
        dataType: 'json',
        async: false,
        data: { iddevice: $("#txtId").val(), idfuncion: $("#cmbFuncion").val(), nomfuncion: $("#txtNomfunc").val(), ui: $("#cmbUi").val() },
        beforeSend: function () { $("#rotor").show(); },
        success: function (data, textStatus, jqXHR) {
            $("#rotor").hide();
            $("#mensaje").html("El proceso se ha realizado exitosamente.");
            readFuncustom($("#txtId").val());
        }
    });
}

// Pagina de correos
function sendCorreo() {
    $.ajax({
        method: 'POST',
        url: '../api/cliente',
        dataType: 'json',
        async: false,
        data: { d0:"4", d1: $("#txtCorreo").val(), d2: $("#txtMensaje").val() },
        beforeSend: function () { $("#rotor").show(); },
        success: function (data, textStatus, jqXHR) {
            $("#rotor").hide();
            if (data===1)
                $("#mensaje").html("El proceso se ha realizado exitosamente.");
        }
    });
}

// Pagina de prueba equipos
function sendComando() {
    $.ajax({
        method: 'POST',
        url: '../api/sistema',
        dataType: 'json',
        async: false,
        data: { d0: "2", d1: $("#cmbTipo").val(), d2: $("#txtSerie").val(), d3:$("#txtComando").val() },
        beforeSend: function () { $("#rotor").show(); },
        success: function (data, textStatus, jqXHR) {
            if (data === 1) {
                $("#mensaje").html("El proceso se ha realizado exitosamente.");
                $("#mAvisos").show();
            }
            $("#rotor").hide();
        }
    });
}

function sendTest() {
    $.ajax({
        method: 'POST',
        url: '../api/sistema',
        dataType: 'json',
        async: false,
        data: { d0: "3", d1: $("#cmbTipo").val(), d2: $("#txtSerie").val(), d3: $("#cmbComando").val(), d4: $("#rdAccion:checked").val(), d5:$("#txtKey").val() },
        beforeSend: function () { $("#rotor").show(); },
        success: function (data, textStatus, jqXHR) {
            if (data === 1) {
                $("#mensaje").html("El proceso se ha realizado exitosamente.");
                $("#mAvisos").show();
            }
            $("#rotor").hide();
        }
    });
}

function leeFxtmp() {
    var uri = '../api/sistema?op=fxtpm&pda=' + $("#cmbTipo").val() + '&pde=' + $("#cmbModelo").val() + '&pdi=0';
    var fila = "";
    $.getJSON(uri)
        .done(function (data) {
            $("#cmbComando").children().remove();
            $.each(data, function (key, item) {
                fila = "<option value='" + item.d0 + "'>" + item.d1 + "</option>";
                $("#cmbComando").append(fila);
            });
        });
}

// Funciones al cargar la pagina
$(document).ready(function () {
    var str = location.href;

    if ($("#btnLogin").length > 0) {
        $("#btnLogin").on("click", function () { inicioSession(); });
    }

    if ($("#btnLostpwd").length > 0) {
        $("#btnLostpwd").on("click", function () { lostPwd(); });
    }

    if (str.indexOf("Regadmin") > 0) {
        $("#mAvisos").hide();
        $("#btnSend").on("click", function () { addAdmin(); });        
    } else if (str.indexOf("equipo") > 0) {
        $("#btnSend").on("click", function () { addDevice(); });
        leeDevice(0);
    } else if (str.indexOf("cliente") > 0) {
        $("#btnSend").on("click", function () { addCliente(); });
        leeCliente(0);
    } else if (str.indexOf("licencia") > 0) {
        $("#btnSend").on("click", function () { updLicencia(); });
    } else if (str.indexOf("matricula") > 0) {
        $("#rotor").hide();
        $("#mAvisos").hide();
        $("#cmbTipo").on("click", function () { loadModelo(); });
        $("#btnSend").on("click", function () { addEquipocliente(); });
        //$("#btnCargaosm").on("click", function () { cargaOsm(); });
        $("#btnUpdfunc").on("click", function () { updFndevices(); });        
        $("#btnFuncionui").on("click", function () { addCustomfn(); });
        $("#txtSerie").on("blur", function () { leeSerie(); });
        $("#txtIdentifica").on("blur", function () { leeCliente(this.value); });
        leeDevice(0);
        $("#cmbTipo").click();
    } else if (str.indexOf("correo") > 0) {
        $("#rotor").hide();
        $("#mAvisos").hide();
        $("#btnSend").on("click", function () { sendCorreo(); });
    } else if (str.indexOf("Testdevice") > 0) { 
        $("#rotor").hide();
        $("#mAvisos").hide();
        $("#btnSend").on("click", function () { sendComando(); });
    } else if (str.indexOf("Pruebamaq") > 0) {
        $("#rotor").hide();
        $("#mAvisos").hide();
        $("#cmbTipo").on("click", function () { loadModelo(); });
        $("#cmbModelo").on("click", function () { leeFxtmp(); });
        $("#btnSend").on("click", function () { sendTest(); });
        $("#cmbTipo").click();
        $("#cmbModelo").click();
    }

});